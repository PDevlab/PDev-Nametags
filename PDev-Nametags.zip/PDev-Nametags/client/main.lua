--[[ =====================================================================
        PDev-Nametags  |  Main client (rendering + toggles)
===================================================================== ]]--

local KVP_NAMETAGS  = 'pdev_nametags_on'
local KVP_HEALTHBAR = 'pdev_healthbar_on'

-- Live state ----------------------------------------------------------
local nametagsOn  = Config.DefaultNametagsOn
local healthBarOn = Config.HealthBar.enabled and Config.HealthBar.defaultOn or false

------------------------------------------------------------------------
-- Hex colour parsing  ->  { r, g, b, a }
------------------------------------------------------------------------
local hexCache = {}
local function hex(str, defaultAlpha)
    if type(str) == 'table' then return str end -- allow raw {r,g,b,a} too
    local key = tostring(str) .. '|' .. tostring(defaultAlpha)
    local cached = hexCache[key]
    if cached then return cached end

    local s = tostring(str):gsub('#', '')
    local r = tonumber(s:sub(1, 2), 16) or 255
    local g = tonumber(s:sub(3, 4), 16) or 255
    local b = tonumber(s:sub(5, 6), 16) or 255
    local a = (#s >= 8 and tonumber(s:sub(7, 8), 16)) or defaultAlpha or 255

    local c = { r, g, b, a }
    hexCache[key] = c
    return c
end

------------------------------------------------------------------------
-- Draw helpers
------------------------------------------------------------------------
-- Draw centred 3D text at a world point, offset in screen space by (ox, oy).
local function drawText(x, y, z, ox, oy, text, scale, color, underline, ulWidth)
    SetDrawOrigin(x, y, z, 0)
    SetTextScale(0.0, scale)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(color[1], color[2], color[3], color[4] or 255)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextDropShadow()
    SetTextEdge(2, 0, 0, 0, 255)   -- strong black outline like image 1
    SetTextOutline()
    SetTextEntry('STRING')
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(ox, oy)
    if underline then
        DrawRect(ox, oy + (scale * 0.045) + 0.004, ulWidth or 0.035, 0.0018,
            color[1], color[2], color[3], color[4] or 255)
    end
    ClearDrawOrigin()
end

-- Draw a filled rect in screen space around a world origin.
local function drawRect(x, y, z, ox, oy, w, h, color)
    SetDrawOrigin(x, y, z, 0)
    DrawRect(ox, oy, w, h, color[1], color[2], color[3], color[4] or 255)
    ClearDrawOrigin()
end

local function hpColor(pct)
    local hb = Config.HealthBar
    if not hb.useHealthColor then return hex(hb.color) end
    if pct > 0.60 then return hex(hb.highColor)
    elseif pct > 0.25 then return hex(hb.midColor)
    else return hex(hb.lowColor) end
end

------------------------------------------------------------------------
-- Resolve display name
------------------------------------------------------------------------
local function getDisplayName(playerId, serverId)
    local name
    if Config.NameStatebag then
        local ply = Player(serverId)
        if ply and ply.state and ply.state[Config.NameStatebag] then
            name = ply.state[Config.NameStatebag]
        end
    end
    name = name or GetPlayerName(playerId) or 'Unknown'
    if Config.ShowServerId then
        name = ('%s (%s)'):format(name, serverId)
    end
    return name
end

------------------------------------------------------------------------
-- Render one player's nametag stack
------------------------------------------------------------------------
local function renderPlayer(playerId, myCoords)
    local isSelf = (playerId == PlayerId())
    if isSelf and not Config.ShowOwnNametag then return end

    local ped = GetPlayerPed(playerId)
    if ped == 0 or not DoesEntityExist(ped) then return end

    local pedCoords = GetEntityCoords(ped)
    local dist = #(myCoords - pedCoords)
    if not isSelf and dist > Config.MaxDistance then return end

    -- Line-of-sight occlusion: hide the tag if a wall blocks it.
    if not isSelf and Config.UseOcclusionRaycast then
        local myPed = PlayerPedId()
        local from = GetEntityCoords(myPed) + vector3(0, 0, 0.5)
        local to = pedCoords + vector3(0, 0, 0.5)
        local ray = StartShapeTestRay(from.x, from.y, from.z, to.x, to.y, to.z, 1, myPed, 0)
        local _, hit = GetShapeTestResult(ray)
        if hit == 1 then return end
    end

    local serverId = GetPlayerServerId(playerId)

    -- Gentle distance scaling for readability.
    local scale = Config.NameScale
    if Config.ScaleWithDist and not isSelf then
        local f = 1.0 - (dist / (Config.MaxDistance * 3.0))
        if f < Config.MinScaleFactor then f = Config.MinScaleFactor end
        scale = scale * f
    end

    local baseZ = pedCoords.z + Config.HeightOffset
    local x, y = pedCoords.x, pedCoords.y

    -- 1) Name line
    local name = getDisplayName(playerId, serverId)
    drawText(x, y, baseZ, 0.0, 0.0, name, scale, hex(Config.NameColor))

    -- 2) Talking indicator (above the name)
    if Config.Talking.enabled then
        local talking, mode = PDevVoice.GetTalking(playerId, serverId)
        if talking then
            local t = Config.Talking
            local info = (mode and t.modes[mode]) or t.genericLabel
            drawText(x, y, baseZ, 0.0, -t.yOffset, info.label, scale * t.scale,
                hex(info.color), t.underline, 0.030)
        end
    end

    -- 3) Synced status line (death / laststand) - just above the name
    if Config.Status.enabled then
        local status = PDevStatus.Get(serverId)
        if status then
            local s = Config.Status
            local info = (status == 'dead') and s.dead or s.laststand
            drawText(x, y, baseZ, 0.0, -s.yOffset, info.label, scale * s.scale,
                hex(info.color), true, 0.032)
        end
    end

    -- 4) Health bar (below the name) - only when the feature + toggle are on
    if Config.HealthBar.enabled and healthBarOn then
        local hb = Config.HealthBar
        local health = GetEntityHealth(ped)          -- 0..200 (100 = dead threshold)
        local pct = (health - 100) / 100.0
        if pct < 0 then pct = 0 elseif pct > 1 then pct = 1 end

        local by = hb.yOffset
        -- background / track
        drawRect(x, y, baseZ, 0.0, by, hb.width + 0.004, hb.height + 0.004, hex(hb.backColor, 204))
        -- filled portion (left-aligned so it depletes from the right)
        local fill = hb.width * pct
        drawRect(x, y, baseZ, -(hb.width / 2) + (fill / 2), by, fill, hb.height, hpColor(pct))

        -- armor segment above the health bar
        if hb.showArmor then
            local armor = GetPedArmour(ped)
            if armor > 0 then
                local apct = math.min(armor / 100.0, 1.0)
                local afill = hb.width * apct
                local ay = by - (hb.height + 0.0026)
                drawRect(x, y, baseZ, -(hb.width / 2) + (afill / 2), ay, afill, hb.height * 0.5, hex(hb.armorColor))
            end
        end
    end
end

------------------------------------------------------------------------
-- Main render loop
------------------------------------------------------------------------
CreateThread(function()
    -- Load persisted prefs
    if Config.PersistToggles then
        local n = GetResourceKvpInt(KVP_NAMETAGS)
        if n ~= 0 then nametagsOn = (n == 1) end
        if Config.HealthBar.enabled then
            local h = GetResourceKvpInt(KVP_HEALTHBAR)
            if h ~= 0 then healthBarOn = (h == 1) end
        end
    end

    while true do
        if nametagsOn then
            local myCoords = GetEntityCoords(PlayerPedId())
            for _, playerId in ipairs(GetActivePlayers()) do
                renderPlayer(playerId, myCoords)
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

------------------------------------------------------------------------
-- Commands
------------------------------------------------------------------------
local function savePref(key, value)
    if Config.PersistToggles then SetResourceKvpInt(key, value and 1 or 0) end
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, true)
end

RegisterCommand(Config.Commands.toggleNametags, function()
    nametagsOn = not nametagsOn
    savePref(KVP_NAMETAGS, nametagsOn)
    notify(('Nametags %s'):format(nametagsOn and '~g~ON' or '~r~OFF'))
end, false)

-- Health bar command only registers when the feature is enabled in config.
if Config.HealthBar.enabled then
    RegisterCommand(Config.Commands.toggleHealthBar, function()
        healthBarOn = not healthBarOn
        savePref(KVP_HEALTHBAR, healthBarOn)
        if healthBarOn and not nametagsOn then
            notify('Health bar ~g~ON~s~ (enable nametags with /' .. Config.Commands.toggleNametags .. ')')
        else
            notify(('Health bar %s'):format(healthBarOn and '~g~ON' or '~r~OFF'))
        end
    end, false)
end

-- Expose current state for other resources / debugging.
exports('AreNametagsOn', function() return nametagsOn end)
exports('IsHealthBarOn', function() return healthBarOn end)
