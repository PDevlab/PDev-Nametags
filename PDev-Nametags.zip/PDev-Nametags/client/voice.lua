--[[ =====================================================================
        PDev-Nametags  |  Voice / talking detection
    Resolves whether a player is talking and, when pma-voice is running,
    WHICH proximity mode (whisper / normal / shout) they use.
===================================================================== ]]--

PDevVoice = {}

local function voiceRunning()
    local res = Config.Talking.voiceResource
    return res and GetResourceState(res) == 'started'
end

-- Map a pma-voice proximity payload to one of our mode keys.
-- pma-voice stores state.proximity = { index = 1|2|3, distance, mode = 'Whisper'|'Normal'|'Shouting' }
local function resolveMode(proximity)
    if type(proximity) ~= 'table' then return nil end

    -- Prefer the string mode (substring match handles 'Shouting', 'Shout', etc).
    if type(proximity.mode) == 'string' then
        local m = string.lower(proximity.mode)
        if m:find('whisper') then return 'whisper' end
        if m:find('shout')   then return 'shout'   end
        if m:find('normal')  then return 'normal'  end
    end

    -- Fall back to the numeric index (1 = whisper, 2 = normal, 3 = shout).
    local idx = proximity.index
    if idx == 1 then return 'whisper'
    elseif idx == 2 then return 'normal'
    elseif idx == 3 then return 'shout' end

    return nil
end

-- Is this player actually talking? Mumble (what pma-voice uses) first,
-- with the legacy native as a fallback.
local function isTalking(playerId)
    local ok, talking = pcall(MumbleIsPlayerTalking, playerId)
    if ok and talking then return true end
    if NetworkIsPlayerTalking(playerId) then return true end
    return false
end

--- Returns talking = boolean, mode = 'whisper'|'normal'|'shout'|nil
--- @param playerId number  local player index (from GetPlayerFromServerId / PlayerId)
--- @param serverId number  server id (for statebag lookups)
function PDevVoice.GetTalking(playerId, serverId)
    if not Config.Talking.enabled then return false, nil end
    if playerId == nil or playerId == -1 then return false, nil end

    if not isTalking(playerId) then return false, nil end

    -- Enrich with the proximity mode from pma-voice's replicated statebag.
    if voiceRunning() then
        local ply = Player(serverId)
        if ply and ply.state then
            local mode = resolveMode(ply.state.proximity)
            if mode then return true, mode end
        end
    end

    return true, nil
end
