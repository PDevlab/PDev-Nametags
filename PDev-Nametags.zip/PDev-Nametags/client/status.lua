--[[ =====================================================================
        PDev-Nametags  |  Synced death & laststand status
    Detects the LOCAL player's death / laststand from ANY framework or
    ambulance script, then pushes it into a replicated statebag so every
    other client can render "** Dead **" / "** UHH **".

    It is intentionally source-agnostic: it checks known ambulance exports,
    common statebag keys, framework metadata and the native death flag, so
    it works with esx_ambulancejob, qb-ambulancejob, qbx_medical,
    wasabi_ambulance, ars_ambulance, aj-medical, and most others.
===================================================================== ]]--

PDevStatus = {}

local STATE_KEY = 'pdev_status'   -- replicated statebag key
local currentStatus = nil          -- 'dead' | 'laststand' | nil

--- Set & replicate the local player's status. Only real changes replicate.
function PDevStatus.Set(status)
    if status ~= 'dead' and status ~= 'laststand' then status = nil end
    if status == currentStatus then return end
    currentStatus = status
    LocalPlayer.state:set(STATE_KEY, status, true) -- true = replicated to others
end

--- Read another player's synced status.
function PDevStatus.Get(serverId)
    local ply = Player(serverId)
    if ply and ply.state then
        return ply.state[STATE_KEY]
    end
    return nil
end

exports('SetStatus', PDevStatus.Set)
exports('GetStatus', PDevStatus.Get)

------------------------------------------------------------------------
-- Known ambulance resources (for auto-detection logging + export checks)
------------------------------------------------------------------------
-- Each entry: resource name, and an optional export that returns a "dead"
-- boolean. Order = priority when several are running.
local AMBULANCES = {
    { resource = 'wasabi_ambulance', deadExport = 'isPlayerDead' },
    { resource = 'qbx_medical'      },
    { resource = 'qb-ambulancejob'  },
    { resource = 'esx_ambulancejob' },
    { resource = 'ars_ambulance'    },
    { resource = 'aj-medical'       },
    { resource = 'codem-ambulancejob' },
    { resource = 'origen_police'    }, -- some medical bundles
}

local detectedAmbulance = nil

local function findAmbulance()
    local wanted = Config.Status.ambulance
    if wanted and wanted ~= 'auto' then
        -- explicit resource name in config
        for _, a in ipairs(AMBULANCES) do
            if a.resource == wanted then return a end
        end
        return { resource = wanted } -- unknown but honour it for export lookups
    end
    for _, a in ipairs(AMBULANCES) do
        if GetResourceState(a.resource) == 'started' then return a end
    end
    return nil
end

------------------------------------------------------------------------
-- Detection helpers
------------------------------------------------------------------------
local function stateFlag(keys)
    local st = LocalPlayer.state
    if not st then return false end
    for _, k in ipairs(keys) do
        if st[k] == true then return true end
    end
    return false
end

-- Try an ambulance export (e.g. wasabi_ambulance:isPlayerDead) safely.
local function ambulanceDead()
    if not detectedAmbulance or not detectedAmbulance.deadExport then return nil end
    local res, fn = detectedAmbulance.resource, detectedAmbulance.deadExport
    local ok, result = pcall(function()
        return exports[res][fn](exports[res])
    end)
    if ok then return result == true end
    return nil
end

-- Framework metadata (qb / qbx / esx) if present.
local frameworkMeta = nil
local function primeFramework()
    if GetResourceState('qbx_core') == 'started' or GetResourceState('qb-core') == 'started' then
        local coreRes = GetResourceState('qbx_core') == 'started' and 'qbx_core' or 'qb-core'
        local ok, core = pcall(function() return exports[coreRes]:GetCoreObject() end)
        if ok and core then
            frameworkMeta = function()
                local ok2, pd = pcall(function() return core.Functions.GetPlayerData() end)
                if ok2 and pd and pd.metadata then return pd.metadata end
                return nil
            end
        end
    end
end

------------------------------------------------------------------------
-- Universal poller: figures out the strongest available signal each tick.
------------------------------------------------------------------------
local function computeStatus()
    -- 1) Laststand flags win first (a downed state is more specific than dead).
    if stateFlag(Config.Status.laststandStates) then return 'laststand' end

    -- 2) Framework metadata laststand
    if frameworkMeta then
        local md = frameworkMeta()
        if md then
            if md.inlaststand or md.isInLaststand then return 'laststand' end
            if md.isdead then return 'dead' end
        end
    end

    -- 3) Dead flags (statebags)
    if stateFlag(Config.Status.deadStates) then return 'dead' end

    -- 4) Ambulance export
    local aDead = ambulanceDead()
    if aDead == true then return 'dead' end

    -- 5) Native fallback
    if IsEntityDead(PlayerPedId()) then return 'dead' end

    return nil
end

------------------------------------------------------------------------
-- Boot
------------------------------------------------------------------------
CreateThread(function()
    if not Config.Status.enabled then return end

    local mode = Config.Status.detection
    if mode == 'external' then return end -- another resource drives exports.SetStatus

    detectedAmbulance = findAmbulance()
    primeFramework()

    if detectedAmbulance then
        print(('^2[%s]^7 Death/laststand source: %s')
            :format(Config.ResourceLabel or 'PDev-Nametags', detectedAmbulance.resource))
    else
        print(('^3[%s]^7 No known ambulance detected - using framework/native death detection.')
            :format(Config.ResourceLabel or 'PDev-Nametags'))
    end

    if mode == 'standalone' then
        -- Native only, no laststand concept.
        while true do
            Wait(500)
            PDevStatus.Set(IsEntityDead(PlayerPedId()) and 'dead' or nil)
        end
    end

    -- Universal poller (covers auto/esx/qb/qbx and every ambulance).
    while true do
        Wait(Config.Status.pollMs or 400)
        PDevStatus.Set(computeStatus())
    end
end)
