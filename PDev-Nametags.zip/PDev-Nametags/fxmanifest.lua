fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'PDev-Nametags'
author 'PDev'
description 'PDev-Nametags - Overhead player nametags with optional health bar, talking indicators (whisper/talk/shout) and synced death & laststand status.'
version '1.0.0'

shared_script 'config.lua'

client_scripts {
    'client/voice.lua',
    'client/status.lua',
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}
