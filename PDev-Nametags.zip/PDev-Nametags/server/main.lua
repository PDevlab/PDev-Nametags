--[[ =====================================================================
        PDev-Nametags  |  Server
    Statebags used for status syncing replicate automatically, so the
    server stays light. This file validates config and prints branding.
===================================================================== ]]--

CreateThread(function()
    Wait(50)
    print(('^2[%s]^7 v%s loaded.'):format(
        Config.ResourceLabel,
        GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0'))

    if not Config.HealthBar.enabled then
        print(('^3[%s]^7 Health bar feature is DISABLED in config (/%s is inactive).')
            :format(Config.ResourceLabel, Config.Commands.toggleHealthBar))
    end
    if not Config.Talking.enabled then
        print(('^3[%s]^7 Talking indicators are DISABLED in config.'):format(Config.ResourceLabel))
    end
    if not Config.Status.enabled then
        print(('^3[%s]^7 Synced death/laststand status is DISABLED in config.'):format(Config.ResourceLabel))
    end
end)

-- Clear a disconnecting player's replicated status so it never lingers.
AddEventHandler('playerDropped', function()
    local src = source
    local ply = Player(src)
    if ply and ply.state then
        ply.state:set('pdev_status', nil, true)
    end
end)
