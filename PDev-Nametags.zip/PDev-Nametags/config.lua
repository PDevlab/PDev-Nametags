--[[ =====================================================================
        PDev-Nametags  |  Configuration
    All branding, toggles and tuning live here.

    COLORS: every colour below is a HEX string. You may use:
        "#RRGGBB"      e.g. "#FF2A2A"  (alpha defaults to 255)
        "#RRGGBBAA"    e.g. "#FF2A2ACC" (with alpha)
    Case doesn't matter and the leading '#' is optional.
===================================================================== ]]--

Config = {}

------------------------------------------------------------------------
-- GENERAL
------------------------------------------------------------------------

-- Distance (in game units) within which you can see OTHER players' nametags.
-- Beyond this radius nothing is drawn. Requested default = 3.0.
Config.MaxDistance = 3.0

-- Nametags start hidden. Players enable them per-session with /Togglenametags.
-- Set true if you want them ON the moment a player spawns.
Config.DefaultNametagsOn = false

-- Show YOUR OWN nametag above your head (visible in third person / mirrors).
Config.ShowOwnNametag = true

-- Persist a player's toggle choices between sessions on the same PC (KVP).
Config.PersistToggles = true

-- Show the server ID in brackets after the name -> "Sweyn Forkbeard (3)"
Config.ShowServerId = true

-- How the on-screen name is resolved. GetPlayerName is used by default. Set a
-- statebag key here to override, e.g. 'name' reads Player(id).state.name.
Config.NameStatebag = nil

-- Text / draw tuning
Config.NameScale        = 0.50    -- base text scale for the name (bigger = larger)
Config.NameColor        = '#FFFFFF'
Config.HeightOffset     = 1.02    -- units above the ped's head for the name line
Config.ScaleWithDist    = true    -- shrink text slightly as distance grows
Config.MinScaleFactor   = 0.80    -- never shrink below this fraction of NameScale
Config.UseOcclusionRaycast = true -- hide nametag if a wall is between you and them

------------------------------------------------------------------------
-- COMMAND NAMES  (change these to rebrand the commands)
------------------------------------------------------------------------
Config.Commands = {
    toggleNametags  = 'Togglenametags',   -- /Togglenametags
    toggleHealthBar = 'TogglenametagsH',  -- /TogglenametagsH
}

------------------------------------------------------------------------
-- HEALTH BAR  (the red underline bar seen under the name)
------------------------------------------------------------------------
Config.HealthBar = {
    -- MASTER SWITCH. If false the /TogglenametagsH command is disabled entirely
    -- and no server will ever show the health bar. Flip to true to allow it.
    enabled       = true,

    -- Whether the bar starts ON when nametags are on. Players still control it
    -- live with /TogglenametagsH (when enabled = true).
    defaultOn     = true,

    width         = 0.050,   -- bar width (screen space)
    height        = 0.006,   -- bar thickness (thin line, like image 2)
    yOffset       = 0.044,   -- vertical drop below the name (bigger = lower)

    -- If true, the bar changes green->yellow->red with health.
    -- If false, the bar is always `color` (the requested solid RED look).
    useHealthColor = false,
    color          = '#FFC0CB',   -- solid bar colour when useHealthColor = false

    -- Gradient colours (only used when useHealthColor = true)
    highColor      = '#5FC85F',   -- > 60% hp
    midColor       = '#E6C83C',   -- 25% - 60% hp
    lowColor       = '#D2413C',   -- < 25% hp

    -- Track / background behind the bar
    backColor      = '#000000CC',

    -- Thin armor segment drawn above the health bar
    showArmor      = true,
    armorColor     = '#5A96EB',
}

------------------------------------------------------------------------
-- TALKING INDICATOR  (whisper / normal / shout)  -- "Normal..." line
------------------------------------------------------------------------
Config.Talking = {
    enabled       = true,

    -- Voice resource used to detect the proximity MODE. pma-voice is supported
    -- out of the box (reads the 'proximity' statebag). If it isn't running the
    -- script still shows a generic "Talking..." label using native detection.
    voiceResource = 'pma-voice',

    yOffset       = 0.030,   -- gap above the name for the talking label
    scale         = 0.80,    -- relative to NameScale
    underline     = true,    -- little underline under the talking word

    -- label & colour per mode
    modes = {
        whisper = { label = 'Whisper...', color = '#96BEFF' },
        normal  = { label = 'Normal...',  color = '#E6963C' },  -- orange, like image 1
        shout   = { label = 'Shout...',   color = '#FF965A' },
    },
    -- Fallback label when the mode can't be resolved (no pma-voice).
    genericLabel  = { label = 'Talking...', color = '#E6963C' },
}

------------------------------------------------------------------------
-- SYNCED STATUS  (death & laststand)  -- the "** Yaralı **" line
------------------------------------------------------------------------
Config.Status = {
    enabled = true,

    yOffset = 0.030,  -- gap above the name for the status line
    scale   = 0.85,

    dead      = { label = '** Dead **',   color = '#C83C3C' },
    laststand = { label = '** UHH **', color = '#D2783C' }, -- injured / downed

    -- Detection mode for YOUR OWN status (it is then synced to everyone).
    --   'auto'       -> universal detector: works with any framework AND any
    --                   ambulance script (recommended). See below.
    --   'standalone' -> native IsEntityDead only (no laststand concept)
    --   'external'   -> you push status yourself via the export (see README)
    detection = 'auto',

    -- Which ambulance/medical resource to read.
    --   'auto'  -> auto-detect the running ambulance job (wasabi_ambulance,
    --             qbx_medical, qb-ambulancejob, esx_ambulancejob, ars_ambulance,
    --             aj-medical, codem-ambulancejob, ...). Prints what it found.
    --   or set a specific resource name to force it, e.g. 'wasabi_ambulance'.
    ambulance = 'auto',

    -- How often (ms) to re-check your status. Lower = snappier, tiny bit heavier.
    pollMs = 400,

    -- Statebag keys scanned to decide DEAD. Most ambulance/medical scripts set
    -- one of these on LocalPlayer.state. Add your own if yours differs.
    deadStates      = { 'isdead', 'isDead', 'dead' },

    -- Statebag keys scanned to decide LASTSTAND / downed.
    laststandStates = { 'laststand', 'inlaststand', 'inLaststand', 'isLaststand', 'lastStand' },
}

------------------------------------------------------------------------
-- BRANDING
------------------------------------------------------------------------
Config.ResourceLabel = 'PDev-Nametags'
